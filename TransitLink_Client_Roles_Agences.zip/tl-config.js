/* Configuration de l'agence : nom, logo, villes. Stockée dans le navigateur (démonstration).
   À remplacer par Firestore (organisations/{id}) et Firebase Storage (logos/{id}) au branchement. */
(function(){
const K='tl_agency',D={name:'',logo:'',cities:['Kinshasa','Lubumbashi','Goma','Cotonou']};
function load(){let v={};try{v=JSON.parse(localStorage.getItem(K)||'{}')||{}}catch(e){}
v=Object.assign({},D,v);if(Array.isArray(v.cities))v.cities=v.cities.map(c=>typeof c==='string'?c:(c&&typeof c==='object'?(c.name||c.nom||c.city||c.ville||c.label||''):'')).map(x=>String(x).trim()).filter(Boolean);if(!Array.isArray(v.cities)||!v.cities.length)v.cities=D.cities.slice();if(!/^data:image\//.test(v.logo||''))v.logo='';return v}
const OK=/^[\p{L}\p{N}][\p{L}\p{N} .'’\-–]*$/u;
const TL=window.TL={
 get:load,
 esc:s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
 save(p){const v=Object.assign(load(),p);try{localStorage.setItem(K,JSON.stringify(v))}catch(e){return false}TL.apply();return true},
 cities:()=>load().cities.slice(),
 check(n,list){n=(n||'').trim().replace(/\s+/g,' ');if(!n)return 'Saisissez le nom de la ville.';if(n.length>40)return 'Nom trop long (40 caractères maximum).';if(!OK.test(n))return 'Caractères non autorisés dans le nom de la ville.';if(list.some(x=>x.toLowerCase()===n.toLowerCase()))return 'Cette ville existe déjà.';return ''},
 addCity(n){const c=load().cities,m=TL.check(n,c);if(m)return m;c.push(n.trim().replace(/\s+/g,' '));return TL.save({cities:c})?'':'Enregistrement impossible sur cet appareil.'},
 removeCity(n){const c=load().cities;if(c.length<=1)return 'Une agence doit garder au moins une ville.';return TL.save({cities:c.filter(x=>x!==n)})?'':'Enregistrement impossible sur cet appareil.'},
 logoFromFile(f,cb){if(!/^image\/(png|jpeg|webp|svg\+xml)$/.test(f.type))return cb('Format non pris en charge (PNG, JPG, WebP ou SVG).');
  if(f.size>2*1024*1024)return cb('Fichier trop lourd (2 Mo maximum).');
  const r=new FileReader();r.onerror=()=>cb('Lecture du fichier impossible.');
  r.onload=()=>{const im=new Image();im.onerror=()=>cb('Image illisible.');
   im.onload=()=>{const S=256,c=document.createElement('canvas');c.width=c.height=S;const w0=im.width||S,h0=im.height||S,k=Math.min(S/w0,S/h0),w=w0*k,h=h0*k;c.getContext('2d').drawImage(im,(S-w)/2,(S-h)/2,w,h);cb('',c.toDataURL('image/png'))};
   im.src=r.result};r.readAsDataURL(f)},
 apply(){const a=load();let st=document.getElementById('tl-brand');if(!st){st=document.createElement('style');st.id='tl-brand';document.head.appendChild(st)}
  st.textContent=a.logo?'.logo{background:#fff url("'+a.logo+'") center/86% no-repeat!important}.fullogo.custom{width:104px;height:104px;object-fit:contain;mix-blend-mode:normal;margin:0 0 8px;border-radius:20px;box-shadow:0 6px 18px rgba(8,47,50,.15)}':'';
  document.querySelectorAll('.fullogo').forEach(i=>{if(!i.dataset.def)i.dataset.def=i.getAttribute('src');if(a.logo){i.src=a.logo;i.classList.add('custom')}else{i.src=i.dataset.def;i.classList.remove('custom')}});
  document.querySelectorAll('.brand-name').forEach(b=>{if(b.firstChild&&b.firstChild.nodeType===3){if(!b.dataset.def)b.dataset.def=b.firstChild.nodeValue;b.firstChild.nodeValue=a.name||b.dataset.def}})}
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',TL.apply);else TL.apply();
})();
