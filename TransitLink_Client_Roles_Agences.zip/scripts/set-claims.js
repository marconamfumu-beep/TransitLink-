// Donne un rôle (et une agence) à un utilisateur déjà créé dans Firebase Authentication.
//   node scripts/set-claims.js proprio@mail.com proprietaire
//   node scripts/set-claims.js directeur.cotonou@mail.com directeur Cotonou
//   node scripts/set-claims.js caisse.cotonou@mail.com caissier_colis Cotonou
// Rôles : proprietaire, administrateur, directeur, caissier_colis (caissier + agent colis, une seule personne), client
// L'agence est obligatoire pour directeur et caissier_colis (même orthographe que dans « Mon agence »).
const admin=require('firebase-admin');admin.initializeApp({credential:admin.credential.applicationDefault()});
const ROLES=['proprietaire','administrateur','directeur','caissier_colis','client'],PAR_AGENCE=['directeur','caissier_colis'];
(async()=>{const [email,role,agence]=process.argv.slice(2);if(!email||!role)throw new Error('Usage : email role [agence]');
if(!ROLES.includes(role))throw new Error('Rôle inconnu. Choisir parmi : '+ROLES.join(', '));
if(PAR_AGENCE.includes(role)&&!agence)throw new Error('Ce rôle exige une agence : node scripts/set-claims.js '+email+' '+role+' Cotonou');
const claims=PAR_AGENCE.includes(role)?{role,agence}:{role};
const u=await admin.auth().getUserByEmail(email);await admin.auth().setCustomUserClaims(u.uid,claims);
console.log('OK',email,JSON.stringify(claims),'(déconnexion/reconnexion nécessaire)')})().catch(e=>{console.error(e.message);process.exit(1)});
