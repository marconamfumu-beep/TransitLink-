/* TransitLink : application du personnel (démonstration).
   Chaque profil ne voit que ce qui concerne son travail et son agence. */
const $=s=>document.querySelector(s);
const AGN=(()=>{const seen=new Set();return TL.cities().map(c=>typeof c==='string'?c:(c&&typeof c==='object'?(c.name||c.nom||c.city||c.ville||c.label||c.title||Object.values(c).find(v=>typeof v==='string')||''):String(c||''))).map(x=>String(x).trim()).filter(x=>x&&!seen.has(x.toLowerCase())&&seen.add(x.toLowerCase()))})();
const CTRY={Kinshasa:'RDC',Lubumbashi:'RDC',Goma:'RDC',Cotonou:'Bénin'},CURS=['FCFA','USD','CDF'],PAID='Payé au bénéficiaire';
const esc=TL.esc,money=n=>Math.abs(n).toLocaleString('fr-FR');

/* ───────── Session et droits ───────── */
const SESS_KEY='tl_session_v1';let sess=null;
const DEMO_NAMES={directeur:'Directeur',caissier_colis:'Caissier(ère)',proprietaire:'Propriétaire'};
const ME=()=>sess?sess.agency:'',isAll=()=>!!sess&&TLAccess.all(sess.role),can=p=>!!sess&&TLAccess.can(sess.role,p);
const hasPage=p=>!!sess&&TLAccess.pages(sess.role).includes(p);

/* ───────── Données de démonstration ───────── */
const mkP=(id,sender,receiver,from,to,date,status,desc,weight,fee,cur)=>({id,sender,receiver,from,to,date,status,desc,weight,fee,cur});
const mkT=(id,sender,beneficiary,val,cur,from,agency,status,date)=>({id,sender,beneficiary,val,cur,amount:val.toLocaleString('fr-FR')+' '+cur,from,agency,status,date,fee:Math.round(val*0.02)});
const parcels=[
 mkP('TL-26001','M. Kabeya','A. Hounkpatin','Kinshasa','Cotonou','28/10/2026','En transit','Vêtements et chaussures',12,36000,'FCFA'),
 mkP('TL-26002','Mme Ilunga','J. Ahouandjinou','Lubumbashi','Cotonou','27/10/2026','Arrivé','Matériel électronique',5,48000,'FCFA'),
 mkP('TL-26003','M. Banza','C. Sossou','Goma','Cotonou','26/10/2026','Enregistré','Produits alimentaires',20,30000,'FCFA'),
 mkP('TL-26004','Mme Mbuyi','P. Kossi','Cotonou','Kinshasa','25/10/2026','Livré','Documents et cadeaux',3,18000,'FCFA'),
 mkP('TL-26005','M. Tshala','R. Dossou','Cotonou','Lubumbashi','29/10/2026','Emballé','Tissus wax, 2 cartons',14,42000,'FCFA'),
 mkP('TL-26006','Mme Kasongo','D. Agbo','Kinshasa','Goma','29/10/2026','En transit','Pièces détachées',9,25,'USD'),
 mkP('TL-26007','M. Mukendi','S. Tokpanou','Lubumbashi','Kinshasa','30/10/2026','Enregistré','Vêtements, 1 valise',11,30000,'FCFA'),
 mkP('TL-26008','Mme Zola','B. Gnonlonfoun','Cotonou','Goma','30/10/2026','En transit','Produits cosmétiques',6,28000,'FCFA')
];
const transfers=[
 mkT('TR-8101','M. Kabeya','A. Hounkpatin',250,'USD','Kinshasa','Cotonou','À valider','28/10/2026'),
 mkT('TR-8102','Mme Ilunga','J. Ahouandjinou',150000,'FCFA','Lubumbashi','Cotonou','Disponible','27/10/2026'),
 mkT('TR-8103','M. Banza','C. Sossou',80000,'CDF','Cotonou','Goma','En attente','26/10/2026'),
 mkT('TR-8104','Mme Mbuyi','P. Kossi',420000,'FCFA','Cotonou','Kinshasa','Disponible','29/10/2026'),
 mkT('TR-8105','M. Tshala','K. Mwamba',120,'USD','Kinshasa','Lubumbashi','En attente','30/10/2026'),
 mkT('TR-8106','Mme Zola','F. Ilunga',200000,'CDF','Goma','Kinshasa','À valider','30/10/2026')
];
/* Groupages : plusieurs colis regroupés vers une même agence, 100 kg maximum */
const MAXKG=100;
const groupages=[{id:'GR-501',from:'Cotonou',to:'Lubumbashi',date:'30/10/2026',status:'Ouvert'},{id:'GR-500',from:'Kinshasa',to:'Goma',date:'29/10/2026',status:'Expédié'}];
parcels.find(p=>p.id==='TL-26005').group='GR-501';parcels.find(p=>p.id==='TL-26006').group='GR-500';
const gParcels=g=>parcels.filter(p=>p.group===g.id),gKg=g=>gParcels(g).reduce((s,p)=>s+(Number(p.weight)||0),0);
const events=[];const logEv=t=>events.unshift({ts:Date.now(),agency:ME(),who:sess?sess.name:'',txt:t});

/* ───────── Registres (budgets et paiements) ───────── */
const PAYOUT_KEY='tl_agency_payouts_v1',BUDGET_KEY='tl_agency_budgets_v1';
let payoutLedger=[],budgetLedger=[];
try{payoutLedger=JSON.parse(localStorage.getItem(PAYOUT_KEY)||'[]')||[]}catch(e){payoutLedger=[]}
try{budgetLedger=JSON.parse(localStorage.getItem(BUDGET_KEY)||'[]')||[]}catch(e){budgetLedger=[]}
const savePayouts=()=>localStorage.setItem(PAYOUT_KEY,JSON.stringify(payoutLedger)),saveBudgets=()=>localStorage.setItem(BUDGET_KEY,JSON.stringify(budgetLedger));
function todayISO(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function payDay(x){if(x.day)return x.day;const m=/^(\d{2})\/(\d{2})\/(\d{4})/.exec(x.date||'');return m?m[3]+'-'+m[2]+'-'+m[1]:''}
const agencyBal=(a,c)=>payoutLedger.filter(x=>x.agency===a&&x.cur===c).reduce((s,x)=>s-x.amount,0);
const budgetIn=(a,c,day=todayISO())=>budgetLedger.filter(x=>x.agency===a&&x.cur===c&&x.day===day).reduce((s,x)=>s+x.amount,0);
const budgetUsed=(a,c,day=todayISO())=>payoutLedger.filter(x=>x.agency===a&&x.cur===c&&payDay(x)===day).reduce((s,x)=>s+x.amount,0);
const budgetLeft=(a,c,day=todayISO())=>budgetIn(a,c,day)-budgetUsed(a,c,day);

/* ───────── Ce que chaque profil a le droit de voir ───────── */
const vAgs=()=>isAll()?AGN:(ME()?[ME()]:[]);
const vP=()=>isAll()?parcels:parcels.filter(p=>p.from===ME()||p.to===ME());
const vT=()=>isAll()?transfers:transfers.filter(t=>t.from===ME()||t.agency===ME());
const vG=()=>isAll()?groupages:groupages.filter(g=>g.from===ME()||g.to===ME());
const vLedger=l=>isAll()?l:l.filter(x=>x.agency===ME());

/* ───────── Statistiques par agence ───────── */
function agStats(a){
 const out=parcels.filter(p=>p.from===a),inc=parcels.filter(p=>p.to===a),tOut=transfers.filter(t=>t.from===a),tIn=transfers.filter(t=>t.agency===a),open=tIn.filter(t=>t.status!==PAID);
 const sum=(l,c)=>l.filter(t=>t.cur===c).reduce((s,t)=>s+t.val,0);
 return{out,inc,tOut,tIn,open,
  toPack:out.filter(p=>p.status==='Enregistré').length,
  outRun:out.filter(p=>p.status==='Emballé'||p.status==='En transit').length,
  arriving:inc.filter(p=>p.status==='En transit').length,
  waiting:inc.filter(p=>p.status==='Arrivé').length,
  toPay:Object.fromEntries(CURS.map(c=>[c,sum(open,c)])),
  sent:Object.fromEntries(CURS.map(c=>[c,sum(tOut,c)])),
  paidToday:payoutLedger.filter(x=>x.agency===a&&payDay(x)===todayISO()).length}}
function alerts(){const L=[];AGN.forEach(a=>{const s=agStats(a);
 CURS.forEach(c=>{const need=s.toPay[c];if(need<=0)return;const b=budgetIn(a,c),left=b-budgetUsed(a,c);
  if(b<=0)L.push({lv:'bad',a,t:`Aucun budget en ${c} enregistré aujourd’hui, alors que ${money(need)} ${c} sont à payer.`});
  else if(left<need)L.push({lv:'bad',a,t:`Budget ${c} insuffisant : il reste ${money(left)} pour ${money(need)} à payer (manque ${money(need-left)}).`});
  else if(b>0&&left/b<=.1)L.push({lv:'warn',a,t:`Budget ${c} presque épuisé : il reste ${money(left)} sur ${money(b)}.`})});
 if(s.toPack>0)L.push({lv:'warn',a,t:`${s.toPack} colis enregistré${s.toPack>1?'s':''} pas encore emballé${s.toPack>1?'s':''}.`});
 if(s.waiting>0)L.push({lv:'info',a,t:`${s.waiting} colis arrivé${s.waiting>1?'s':''} en attente de remise au destinataire.`})});
 const o={bad:0,warn:1,info:2};return L.sort((x,y)=>o[x.lv]-o[y.lv])}

/* ───────── Carte prépayée (solde du jour) ───────── */
let cardAg='',cardCur='FCFA';
function cardState(){const l=vAgs();if(!l.includes(cardAg))cardAg=l[0]||'';if(!CURS.includes(cardCur))cardCur='FCFA';const b=budgetIn(cardAg,cardCur),u=budgetUsed(cardAg,cardCur),r=b-u;return{b,u,r,pc:b>0?Math.min(100,Math.round(u/b*100)):0,st:b<=0?'none':r<=0?'zero':r/b<=.1?'low':'ok'}}
function prepaidCard(){const{b,u,r,pc,st}=cardState(),num=String((Array.from(cardAg).reduce((s,x)=>s+x.charCodeAt(0),0)*13)%9000+1000),d=new Date(),dd=String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0'),brand=(TL.get().name||'TransitLink');
 const addBtn=can('budget.write')?`<button class="pc-add" data-cardadd type="button">+ Ajouter<span class="pc-long"> de l’argent</span></button>`:`<span class="pc-ro">Lecture seule</span>`;
 const pills=(isAll()?`<div class="pc-row">${AGN.map(x=>`<button type="button" class="${x===cardAg?'on':''}" data-cardag="${esc(x)}">${esc(x)}</button>`).join('')}</div>`:'')+`<div class="pc-row">${CURS.map(x=>`<button type="button" class="${x===cardCur?'on':''}" data-cardcur="${x}">${x}</button>`).join('')}</div>`;
 return `<section class="pcard" id="pcard" aria-label="Solde du jour"><div class="pc-top"><span class="pc-live">● Solde du jour</span><span class="pc-brand">${esc(brand)}</span></div><div class="pc-main"><div class="pc-chip" aria-hidden="true"></div><div class="pc-bal ${st}"><small>${b>0?'RESTE EN CAISSE':'AUCUN BUDGET AUJOURD’HUI'}</small><strong>${b>0?(r<0?'− ':'')+money(r):'0'} <em>${cardCur}</em></strong></div></div><div class="pc-meta"><span>Budget<b>${money(b)}</b></span><span>Utilisé<b>${money(u)}</b></span></div><div class="pc-track"><div style="width:${pc}%"></div></div><div class="pc-foot"><div class="pc-holder"><small>AGENCE</small><b>${esc(cardAg).toUpperCase()}</b></div><div class="pc-num">•••• ${num}<small>JOUR ${dd}</small></div>${addBtn}</div><div class="pc-pills">${pills}</div></section>`}
function centerPills(){document.querySelectorAll('#pcard .pc-row').forEach(r=>{const b=r.querySelector('.on');if(b)r.scrollLeft=Math.max(0,b.offsetLeft-(r.clientWidth-b.offsetWidth)/2)})}
function miniHTML(){const{r,st,b}=cardState();return `<button class="pm-bal ${st}" type="button" data-cardtop aria-label="Revenir à la carte du solde"><span class="pm-chip" aria-hidden="true"></span><span class="pm-txt"><small>${esc(cardAg)} · ${cardCur}</small><strong>${b>0?(r<0?'− ':'')+money(r):'0'}</strong></span></button>${can('budget.write')?'<button class="pm-add" type="button" data-cardadd>+ Ajouter</button>':''}`}
function refreshCard(){const c=document.getElementById('pcard');if(c){c.outerHTML=prepaidCard();centerPills()}const m=document.getElementById('pmini');if(m)m.innerHTML=miniHTML()}
function setupMini(p){const old=document.getElementById('pmini');if(old)old.remove();if((p!=='finances'&&p!=='transfers')||!document.getElementById('pcard'))return;const m=document.createElement('div');m.id='pmini';m.className='pmini';m.innerHTML=miniHTML();$('#app').appendChild(m);centerPills();syncMini()}
function syncMini(){const m=document.getElementById('pmini'),c=document.getElementById('pcard');if(!m||!c)return;const top=parseFloat(getComputedStyle(m).top)||10;m.classList.toggle('on',c.getBoundingClientRect().bottom<top+4)}
let _raf=0;addEventListener('scroll',()=>{if(_raf)return;_raf=requestAnimationFrame(()=>{_raf=0;syncMini()})},{passive:true});
const recapRows=rows=>`<div class="tld-rows">${rows.map(r=>`<div class="${r[2]||''}"><span>${r[0]}</span><b>${r[1]}</b></div>`).join('')}</div>`;

/* ───────── Paiement d'un transfert (caisse de l'agence qui paie) ───────── */
function payTransfer(id){const t=transfers.find(x=>x.id===id);if(!t||t.status===PAID)return;
 if(!can('transfer.pay')||t.agency!==ME()){tlAlert('Action non autorisée','Seul le caissier ou le directeur de l’agence qui paie ce transfert peut confirmer le paiement.');return}
 const amount=Number(t.val);if(!Number.isFinite(amount)||amount<=0){tlAlert('Montant invalide','Le montant de ce transfert est invalide.');return}
 cardAg=t.agency;cardCur=t.cur;refreshCard();
 if(payoutLedger.some(x=>x.ref===t.id)){t.status=PAID;tlAlert('Déjà comptabilisé','Ce paiement a déjà été comptabilisé.');page('transfers');return}
 const b=budgetIn(t.agency,t.cur),u=budgetUsed(t.agency,t.cur),left=b-u,A=esc(t.agency),C=esc(t.cur);
 if(b<=0){tlDialog({title:'Aucun budget enregistré',body:`<p>L’agence <b>${A}</b> n’a pas encore enregistré d’argent en <b>${C}</b> aujourd’hui. Ajoutez le montant dont elle dispose avant de payer ce transfert.</p>${recapRows([['Budget du jour','0 '+C],['Paiement demandé',money(amount)+' '+C]])}`,actions:[{label:'Fermer'},{label:'Ajouter de l’argent',primary:1,onClick:()=>openAddBudget(t.agency,t.cur,amount)}]});return}
 if(amount>left){tlDialog({title:'Budget insuffisant',body:`<p>Le budget du jour de l’agence <b>${A}</b> en <b>${C}</b> ne couvre pas ce paiement. Ajoutez de l’argent pour continuer.</p>${recapRows([['Budget du jour',money(b)+' '+C],['Déjà utilisé',money(u)+' '+C],['Reste',money(left)+' '+C],['Paiement demandé',money(amount)+' '+C],['Il manque',money(amount-left)+' '+C,'bad']])}`,actions:[{label:'Fermer'},{label:'Ajouter de l’argent',primary:1,onClick:()=>openAddBudget(t.agency,t.cur,amount-left)}]});return}
 tlDialog({title:'Confirmer le paiement',body:`<p>Confirmez uniquement après avoir vérifié que le bénéficiaire a réellement reçu l’argent. Le montant sera déduit du budget du jour.</p>${recapRows([['Bénéficiaire',esc(t.beneficiary)],['Envoyé depuis',esc(t.from||'—')],['Agence qui paie',A],['Montant payé',money(amount)+' '+C],['Reste avant',money(left)+' '+C],['Reste après',money(left-amount)+' '+C,'ok']])}`,actions:[{label:'Annuler'},{label:'Confirmer le paiement',primary:1,onClick:()=>{if(payoutLedger.some(x=>x.ref===t.id))return;payoutLedger.push({ref:t.id,agency:t.agency,client:t.beneficiary,amount,cur:t.cur,day:todayISO(),ts:Date.now(),by:sess.name,date:new Date().toLocaleString('fr-FR')});try{savePayouts()}catch(e){payoutLedger.pop();tlAlert('Enregistrement impossible','Impossible d’enregistrer le mouvement sur cet appareil.');return}t.status=PAID;logEv('Paiement '+t.id+' confirmé');cardAg=t.agency;cardCur=t.cur;tlToast('Paiement confirmé · reste '+money(budgetLeft(t.agency,t.cur))+' '+t.cur);page('transfers')}}]})}

/* ───────── Budgets ───────── */
function budgetCards(){const ro=!can('budget.write');return `<div class="budgets">${vAgs().map(a=>`<article class="bud"><div class="bud-h"><h4>${esc(a)}</h4></div>${CURS.map(c=>{const b=budgetIn(a,c),u=budgetUsed(a,c),r=b-u,pc=b>0?Math.min(100,Math.round(u/b*100)):0;return `<div class="bud-row"><div class="bud-top"><b>${c}</b>${ro?'':`<button class="btn-s bud-add" type="button" data-addbudget="${esc(a)}|${c}">+ Ajouter</button>`}</div>${b>0||u>0?`<div class="bud-nums"><span>Budget<b>${money(b)}</b></span><span>Utilisé<b class="out">${money(u)}</b></span><span>Reste<b class="${r<0?'out':'in'}">${r<0?'− ':''}${money(r)}</b></span></div><div class="track"><div class="fill ${pc>=90?'warn':''}" style="width:${pc}%"></div></div>`:`<p class="bud-empty">Aucun budget enregistré aujourd’hui</p>`}</div>`}).join('')}</article>`).join('')}</div>`}
function budgetHistory(){const t=todayISO(),l=vLedger(budgetLedger).filter(x=>x.day===t).slice().reverse(),ed=can('budget.write');return `<div class="tablewrap"><table><thead><tr><th>Heure</th><th>Agence</th><th>Montant ajouté</th><th>Note</th>${ed?'<th></th>':''}</tr></thead><tbody>${l.map(x=>`<tr><td>${esc(x.time)}</td><td>${esc(x.agency)}</td><td class="in">+ ${money(x.amount)} ${esc(x.cur)}</td><td>${esc(x.note||'—')}</td>${ed&&x.agency===ME()?`<td><button class="btn-s" type="button" data-delbudget="${esc(x.id)}">Annuler</button></td>`:ed?'<td></td>':''}</tr>`).join('')||`<tr><td colspan="${ed?5:4}">Aucun ajout aujourd’hui.</td></tr>`}</tbody></table></div>`}
function openAddBudget(a,c,pre){if(!can('budget.write')){tlAlert('Action non autorisée','Seuls le directeur et le caissier de l’agence peuvent ajouter de l’argent au budget.');return}a=ME();
 openForm('Ajouter de l’argent au budget du jour',[{k:'ag',l:'Agence',o:[a],d:a},{k:'cur',l:'Devise',o:CURS,d:c},{k:'amount',l:'Montant que l’agence a en main',t:'number',req:1,min:1,ph:'Ex. 500000',v:pre?String(pre):undefined},{k:'note',l:'Note (facultatif)',ph:'Ex. Ouverture de caisse'}],v=>{budgetLedger.push({id:'B'+Date.now(),day:todayISO(),ts:Date.now(),time:new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}),agency:ME(),cur:v.cur,amount:Number(v.amount),note:v.note,by:sess.name});try{saveBudgets()}catch(e){budgetLedger.pop();tlAlert('Enregistrement impossible','Impossible d’enregistrer le budget sur cet appareil.');return}logEv('Budget ajouté '+money(Number(v.amount))+' '+v.cur);cardAg=ME();cardCur=v.cur;tlToast('Budget enregistré : '+money(Number(v.amount))+' '+v.cur+' · '+ME());const cur=document.querySelector('nav button.active');page(cur?cur.dataset.page:'finances')},v=>String(v.note||'').length>80?'Note trop longue (80 caractères maximum).':'')}

/* ───────── Tableaux ───────── */
const GREEN=['Arrivé','Livré','Disponible',PAID],ORANGE=['En transit','À valider','En attente','Emballé','Ouvert','Expédié'];
function parcelStep(p){if(!can('parcel.step'))return null;const me=ME();
 if(p.from===me&&p.status==='Enregistré')return['Marquer emballé','Emballé'];
 if(p.from===me&&p.status==='Emballé'&&!p.group)return['Expédier','En transit'];
 if(p.to===me&&p.status==='En transit'&&!p.group)return['Marquer arrivé','Arrivé'];
 if(p.to===me&&p.status==='Arrivé')return['Marquer livré','Livré'];return null}
function dirTag(k,x){if(isAll())return '';const me=ME();if(k==='p')return x.from===me?'<span class="tag out">Départ de mon agence</span>':'<span class="tag in">Arrivée pour mon agence</span>';return x.from===me?'<span class="tag out">Émis par mon agence</span>':'<span class="tag in">À payer chez moi</span>'}
const PRINT='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1h-2M7 14h10v7H7z"/></svg>';
function rows(data,k){return data.map(x=>{const st=k==='p'?parcelStep(x):null,pay=k==='t'&&can('transfer.pay')&&x.agency===ME()&&x.status!==PAID;
 return `<tr><td><b>${esc(x.id)}</b>${x.group?`<br><small class="hint">Groupage ${esc(x.group)}</small>`:''}</td><td>${esc(x.sender)}</td><td>${esc(k==='p'?x.receiver:x.beneficiary)}</td><td>${k==='p'?esc(x.from)+' → '+esc(x.to):esc(x.amount)}</td><td>${k==='p'?esc(x.date):esc(x.from||'—')+' → '+esc(x.agency)}</td><td><span class="status ${GREEN.includes(x.status)?'green':ORANGE.includes(x.status)?'orange':''}">${esc(x.status)}</span></td>${isAll()?'':`<td>${dirTag(k,x)}</td>`}<td><div class="row-actions">${st?`<button class="btn-s" type="button" data-step="${esc(x.id)}">${st[0]}</button>`:''}${pay?`<button class="btn-s" type="button" data-paid="${esc(x.id)}">Confirmer payé</button>`:''}<button class="btn-s btn-inv" type="button" data-inv="${k}:${esc(x.id)}" aria-label="Imprimer la facture ${esc(x.id)}">${PRINT}Facture</button></div></td></tr>`}).join('')}
function table(data,k){if(!data.length)return '<div class="empty"><b>Aucun résultat</b><p>Aucune opération ne correspond à cette recherche pour votre profil.</p></div>';return `<div class="tablewrap"><table><thead><tr><th>Référence</th><th>Expéditeur</th><th>${k==='p'?'Destinataire':'Bénéficiaire'}</th><th>${k==='p'?'Trajet':'Montant'}</th><th>${k==='p'?'Date':'Envoi → paiement'}</th><th>Statut</th>${isAll()?'':'<th>Pour mon agence</th>'}<th>Actions</th></tr></thead><tbody>${rows(data,k)}</tbody></table></div>`}
const head=(t,d,btn='')=>`<div class="pagehead"><div><h2>${t}</h2><p>${d}</p></div>${btn}</div>`;
function scopeOpts(k){return isAll()?['Toutes les agences'].concat(AGN):(k==='p'?['Tous mes colis','Départs de mon agence','Arrivées pour mon agence']:['Tous mes transferts','Émis par mon agence','À payer chez moi'])}
function inScope(x,k,sc){if(!sc)return true;if(isAll())return sc==='Toutes les agences'||(k==='p'?(x.from===sc||x.to===sc):(x.from===sc||x.agency===sc));
 if(sc==='Départs de mon agence'||sc==='Émis par mon agence')return x.from===ME();if(sc==='Arrivées pour mon agence'||sc==='À payer chez moi')return k==='p'?x.to===ME():x.agency===ME();return true}
function groupTable(list){const ed=can('group.write');
 if(!list.length)return '<div class="empty"><b>Aucun groupage</b><p>Créez un groupage pour regrouper plusieurs colis vers une même agence (100 kg maximum).</p></div>';
 return `<div class="tablewrap"><table><thead><tr><th>Groupage</th><th>Trajet</th><th>Colis</th><th>Poids (max ${MAXKG} kg)</th><th>Statut</th>${isAll()?'':'<th>Pour mon agence</th>'}<th>Actions</th></tr></thead><tbody>${list.map(g=>{const kg=gKg(g),pc=Math.min(100,Math.round(kg/MAXKG*100)),ps=gParcels(g),a=[];
  if(ed&&g.from===ME()&&g.status==='Ouvert'){if(kg<MAXKG)a.push(`<button class="btn-s" type="button" data-gadd="${esc(g.id)}">+ Colis</button>`);a.push(`<button class="btn-s" type="button" data-gship="${esc(g.id)}">Expédier${kg<MAXKG?' (même incomplet)':''}</button>`)}
  if(can('parcel.step')&&g.to===ME()&&g.status==='Expédié')a.push(`<button class="btn-s" type="button" data-garr="${esc(g.id)}">Marquer arrivé</button>`);
  return `<tr><td><b>${esc(g.id)}</b><br><small class="hint">${esc(g.date)}</small></td><td>${esc(g.from)} → ${esc(g.to)}</td><td>${ps.length}<br><small class="hint">${ps.map(p=>esc(p.id)).join(', ')||'Vide'}</small></td><td><b>${kg.toLocaleString('fr-FR')} kg</b><div class="track" style="margin-top:6px;min-width:110px"><div class="fill ${pc>=100?'warn':''}" style="width:${pc}%"></div></div></td><td><span class="status ${GREEN.includes(g.status)?'green':ORANGE.includes(g.status)?'orange':''}">${esc(g.status)}</span></td>${isAll()?'':`<td>${dirTag('p',g)}</td>`}<td><div class="row-actions">${a.join('')||'—'}</div></td></tr>`}).join('')}</tbody></table></div>`}
function groupSection(){return `<section class="panel" style="margin-top:15px"><div class="pagehead" style="margin-bottom:10px"><div><h3 style="margin:0">Groupages</h3><p class="hint" style="margin:4px 0 0">Colis regroupés vers une même agence, ${MAXKG} kg maximum chacun. On peut ouvrir plusieurs groupages et expédier un groupage même s’il n’est pas plein.</p></div>${can('group.write')?'<button class="primary" type="button" data-newgroup>+ Nouveau groupage</button>':''}</div>${groupTable(vG())}</section>`}
function newGroup(){if(!can('group.write'))return;const dest=others();if(!dest.length){tlAlert('Destination manquante','Ajoutez au moins une autre ville dans « Mon agence ».');return}
 openForm('Créer un groupage',[{k:'from',l:'Agence de départ (la vôtre)',o:[ME()],d:ME()},{k:'to',l:'Agence d’arrivée',o:dest,d:dest.includes('Cotonou')?'Cotonou':dest[0]}],v=>{const g={id:'GR-'+Date.now().toString().slice(-4),from:ME(),to:v.to,date:new Date().toLocaleDateString('fr-FR'),status:'Ouvert',by:sess.name};groupages.unshift(g);logEv('Groupage '+g.id+' créé');tlToast('Groupage '+g.id+' créé · '+MAXKG+' kg maximum');page('parcels')})}
function addToGroup(id){const g=groupages.find(x=>x.id===id);if(!g||!can('group.write')||g.from!==ME()||g.status!=='Ouvert')return;
 const free=MAXKG-gKg(g),el=parcels.filter(p=>p.from===ME()&&p.to===g.to&&!p.group&&(p.status==='Enregistré'||p.status==='Emballé')&&Number(p.weight)>0&&Number(p.weight)<=free);
 if(!el.length){tlAlert('Aucun colis à ajouter','Il faut un colis de votre agence vers '+g.to+', pas encore dans un groupage, avec son poids renseigné et qui tient dans les '+free+' kg restants. Vous pouvez aussi créer un autre groupage.');return}
 openForm('Ajouter un colis au groupage '+g.id,[{k:'p',l:'Colis à ajouter (il reste '+free+' kg)',o:el.map(p=>p.id+' · '+p.weight+' kg · '+p.sender)}],v=>{const p=parcels.find(x=>x.id===v.p.split(' · ')[0]);if(!p||p.group||gKg(g)+Number(p.weight)>MAXKG){tlAlert('Groupage plein','Ce colis dépasse la limite de '+MAXKG+' kg.');return}p.group=g.id;logEv('Colis '+p.id+' ajouté au groupage '+g.id);tlToast('Colis '+p.id+' ajouté · '+gKg(g)+' / '+MAXKG+' kg');page('parcels')})}
function shipGroup(id){const g=groupages.find(x=>x.id===id);if(!g||!can('group.write')||g.from!==ME()||g.status!=='Ouvert')return;const ps=gParcels(g),kg=gKg(g);
 if(!ps.length){tlAlert('Groupage vide','Ajoutez au moins un colis avant d’expédier.');return}
 const np=ps.filter(p=>p.status==='Enregistré');if(np.length){tlAlert('Colis pas encore emballés','Emballez d’abord : '+np.map(p=>p.id).join(', ')+'.');return}
 tlDialog({title:'Expédier le groupage '+g.id+' ?',body:`<p>${ps.length} colis · <b>${kg.toLocaleString('fr-FR')} kg</b> sur ${MAXKG} kg.${kg<MAXKG?' Le groupage n’est pas plein : vous pouvez l’expédier quand même et en ouvrir un autre ensuite.':''}</p>`,actions:[{label:'Annuler'},{label:'Expédier',primary:1,onClick:()=>{g.status='Expédié';ps.forEach(p=>p.status='En transit');logEv('Groupage '+g.id+' expédié');tlToast('Groupage '+g.id+' expédié vers '+g.to);page('parcels')}}]})}
function arriveGroup(id){const g=groupages.find(x=>x.id===id);if(!g||!can('parcel.step')||g.to!==ME()||g.status!=='Expédié')return;g.status='Arrivé';gParcels(g).forEach(p=>p.status='Arrivé');logEv('Groupage '+g.id+' arrivé');tlToast('Groupage '+g.id+' arrivé');page('parcels')}
const kpi=(l,v,s)=>`<div class="card"><span>${l}</span><strong>${v}</strong><small>${s}</small></div>`;
const rolePill=()=>`<span class="rolepill">${esc(TLAccess.label(sess.role))}${isAll()?' · tout le réseau':' · '+esc(ME())}</span>`;

/* ───────── Pages ───────── */
function recentList(){const a=[];if(hasPage('parcels'))vP().slice(0,6).forEach(p=>a.push(`<div class="activity"><b>Colis ${esc(p.id)} · ${esc(p.from)} → ${esc(p.to)}</b><small>${esc(p.status)} · ${esc(p.date)} ${dirTag('p',p)}</small></div>`));
 if(hasPage('transfers'))vT().slice(0,6).forEach(t=>a.push(`<div class="activity"><b>Transfert ${esc(t.id)} · ${esc(t.amount)}</b><small>${esc(t.from)} → ${esc(t.agency)} · ${esc(t.status)} ${dirTag('t',t)}</small></div>`));
 return a.join('')||'<p class="hint">Rien à afficher pour le moment.</p>'}
function overviewHTML(){const a=ME(),s=agStats(a),r=sess.role,left=c=>money(budgetLeft(a,c))+' '+c;let cards;
 const toPayTxt=CURS.filter(c=>s.toPay[c]>0).map(c=>money(s.toPay[c])+' '+c).join(' · ')||'Rien à payer';
 cards=kpi('Colis à emballer',s.toPack,s.outRun+' départ(s) en cours')+kpi('Colis attendus',s.arriving+s.waiting,s.waiting+' à remettre')+kpi('Transferts à payer',s.open.length,toPayTxt)+kpi('Reste en caisse',left('FCFA'),left('USD')+' · '+left('CDF'));
 return `<section class="hero"><div><span class="live">● Agence de ${esc(a)}</span><h2>${esc(TLAccess.label(r))}</h2><p>Vous voyez uniquement ce qui concerne votre travail et votre agence, y compris ce que les autres agences ont fait pour vous.</p></div><div class="corr"><b>${esc(a)}</b></div></section><div class="stats">${cards}</div><section class="panel" style="margin-top:15px"><h3>Dernières opérations qui me concernent</h3>${recentList()}</section>`}
function diagnosticHTML(){const al=alerts(),P=parcels,T=transfers,open=T.filter(t=>t.status!==PAID),A=al.filter(x=>x.lv==='bad').length;
 const flux=`<div class="tablewrap"><table class="matrix"><thead><tr><th>De ↓ / Vers →</th>${AGN.map(a=>`<th>${esc(a)}</th>`).join('')}</tr></thead><tbody>${AGN.map(f=>`<tr><td><b>${esc(f)}</b></td>${AGN.map(t=>{if(f===t)return '<td class="mx-na">—</td>';const np=P.filter(p=>p.from===f&&p.to===t).length,nt=T.filter(x=>x.from===f&&x.agency===t).length;return `<td>${np||nt?`${np?`<span class="mx p">${np} colis</span>`:''}${nt?`<span class="mx t">${nt} transf.</span>`:''}`:'<span class="mx-na">·</span>'}</td>`}).join('')}</tr>`).join('')}</tbody></table></div>`;
 const per=`<div class="tablewrap"><table><thead><tr><th>Agence</th><th>Colis envoyés</th><th>Colis à recevoir</th><th>À emballer</th><th>Transferts émis</th><th>Transferts à payer</th><th>Reste en caisse</th><th>État</th></tr></thead><tbody>${AGN.map(a=>{const s=agStats(a),n=al.filter(x=>x.a===a),bad=n.some(x=>x.lv==='bad'),warn=n.some(x=>x.lv==='warn');return `<tr><td><b>${esc(a)}</b><br><small class="hint">${esc(CTRY[a]||'Agence')}</small></td><td>${s.out.length}</td><td>${s.arriving+s.waiting}<small class="hint"> (${s.arriving} en route)</small></td><td>${s.toPack}</td><td>${s.tOut.length}</td><td>${s.open.length}</td><td>${CURS.map(c=>`<div>${money(budgetLeft(a,c))} <small class="hint">${c}</small></div>`).join('')}</td><td><span class="status ${bad?'red':warn?'orange':'green'}">${bad?'À corriger':warn?'À surveiller':'OK'}</span></td></tr>`}).join('')}</tbody></table></div>`;
 const vol=`<div class="tablewrap"><table><thead><tr><th>Agence</th>${CURS.map(c=>`<th>${c}<br><small class="hint">envoyé · à payer</small></th>`).join('')}</tr></thead><tbody>${AGN.map(a=>{const s=agStats(a);return `<tr><td><b>${esc(a)}</b></td>${CURS.map(c=>`<td>${money(s.sent[c])} · <b>${money(s.toPay[c])}</b></td>`).join('')}</tr>`}).join('')}</tbody></table></div>`;
 const mv=[].concat(payoutLedger.map(x=>({ts:x.ts||0,a:x.agency,k:'Paiement confirmé',m:'− '+money(x.amount)+' '+x.cur,d:x.date,o:1})),budgetLedger.filter(x=>x.day===todayISO()).map(x=>({ts:x.ts||0,a:x.agency,k:'Budget ajouté',m:'+ '+money(x.amount)+' '+x.cur,d:x.time,o:0}))).sort((x,y)=>y.ts-x.ts).slice(0,10);
 const mvT=`<div class="tablewrap"><table><thead><tr><th>Quand</th><th>Agence</th><th>Mouvement</th><th>Montant</th></tr></thead><tbody>${mv.map(x=>`<tr><td>${esc(x.d)}</td><td>${esc(x.a)}</td><td>${x.k}</td><td class="${x.o?'out':'in'}">${esc(x.m)}</td></tr>`).join('')||'<tr><td colspan="4">Aucun mouvement de caisse pour le moment.</td></tr>'}</tbody></table></div>`;
 const al_h=al.length?`<div class="alerts">${al.map(x=>`<div class="alert ${x.lv}"><b>${esc(x.a)}</b><span>${esc(x.t)}</span></div>`).join('')}</div>`:'<div class="notice">Aucune alerte : budgets suffisants, colis emballés, rien en attente.</div>';
 return `<section class="hero"><div><span class="live">● Diagnostic du réseau</span><h2>Tout le trafic, toutes les caisses</h2><p>Lecture seule : vous contrôlez sans rien modifier. Les colis, transferts et budgets de chaque agence sont réunis ici.</p></div><div class="corr"><b>${AGN.length} agences</b></div></section>
<div class="stats">${kpi('Colis dans le réseau',P.length,P.filter(p=>p.status==='En transit').length+' en transit · '+P.filter(p=>p.status==='Livré').length+' livrés')+kpi('Transferts ouverts',open.length,T.length-open.length+' payés sur '+T.length)+kpi('Alertes caisse et colis',al.length,A+' à corriger')+kpi('Paiements du jour',payoutLedger.filter(x=>payDay(x)===todayISO()).length,'Confirmés par les caisses')}</div>
<section class="panel" style="margin-top:15px"><h3>Alertes</h3>${al_h}</section>
<section class="panel"><h3>État de chaque agence</h3>${per}</section>
<section class="panel"><h3>Flux entre agences</h3><p class="hint" style="margin:-4px 0 12px">Ligne = agence d’envoi, colonne = agence d’arrivée ou de paiement.</p>${flux}</section>
<section class="panel"><h3>Groupages du réseau</h3>${groupTable(groupages)}</section>
<section class="panel"><h3>Transferts d’argent par devise</h3>${vol}</section>
<section class="panel"><h3>Derniers mouvements de caisse (toutes agences)</h3>${mvT}</section>`}
function financesHTML(){const ed=can('budget.write'),cs=CURS,ags=vAgs();
 return prepaidCard()+head('Finances',isAll()?'Budgets et cartes de toutes les agences, en lecture seule.':'Budget du jour et solde de votre agence.')+`<section class="panel"><h3>Budget du jour · ${new Date().toLocaleDateString('fr-FR',{dateStyle:'long'})}</h3><div class="notice">${ed?'Enregistrez ici l’argent que votre agence a en main avant de commencer les travaux. Chaque paiement confirmé est déduit automatiquement de ce budget. Rien n’est transféré : c’est un enregistrement.':'Vous consultez les caisses sans pouvoir les modifier : seuls le directeur et le caissier de chaque agence ajoutent de l’argent à leur budget.'}</div>${budgetCards()}</section><section class="panel"><h3>Ajouts de budget du jour</h3>${budgetHistory()}</section><section class="panel"><h3>Solde${ags.length>1?' par agence':' de l’agence'}</h3><div class="tablewrap"><table><thead><tr><th>Agence</th>${cs.map(c=>`<th>${c}</th>`).join('')}</tr></thead><tbody>${ags.map(a=>`<tr><td><b>${esc(a)}</b></td>${cs.map(c=>{const n=agencyBal(a,c);return `<td class="${n<0?'out':'in'}">${n<0?'− ':''}${money(n)} ${c}</td>`}).join('')}</tr>`).join('')}</tbody></table></div></section><section class="panel"><h3>Historique des paiements confirmés</h3><div class="tablewrap"><table><thead><tr><th>Date</th><th>Référence</th><th>Agence</th><th>Bénéficiaire</th><th>Montant déduit</th></tr></thead><tbody>${vLedger(payoutLedger).slice().reverse().map(x=>`<tr><td>${esc(x.date)}</td><td>${esc(x.ref)}</td><td>${esc(x.agency)}</td><td>${esc(x.client)}</td><td class="out">− ${money(x.amount)} ${esc(x.cur)}</td></tr>`).join('')||'<tr><td colspan="5">Aucun paiement confirmé.</td></tr>'}</tbody></table></div></section><div class="notice">Démonstration : le registre est enregistré sur cet appareil uniquement et ne réalise aucun transfert d’argent.</div>`}
function agenciesHTML(){return head('Réseau des agences',AGN.length+' point'+(AGN.length>1?'s':'')+' du réseau, avec leur activité réelle.')+`<div class="agencies">${AGN.map(a=>{const s=agStats(a),al=alerts().filter(x=>x.a===a&&x.lv!=='info').length;return `<article class="agency"><span class="status ${al?'orange':'green'}">${al?al+' alerte'+(al>1?'s':''):'Active'}</span><h3>${esc(a)}</h3><p>${esc(CTRY[a]||'Agence')}</p><strong>${s.out.length+s.inc.length}</strong><p>Colis (départs + arrivées)</p><strong>${s.tOut.length+s.tIn.length}</strong><p>Transferts (émis + à payer)</p></article>`}).join('')}</div>`}
function page(p){clearInterval(window.lt);if(!sess)return;if(!hasPage(p))p=TLAccess.home(sess.role);
 document.querySelectorAll('nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===p));
 const names={diagnostic:'Diagnostic du réseau',finances:'Finances',overview:'Vue générale',parcels:'Colis',transfers:'Transferts',agencies:'Agences',customers:'Clients',reports:'Rapports',settings:'Paramètres'};$('#title').textContent=names[p];let html='';
 if(p==='overview')html=overviewHTML();
 if(p==='diagnostic')html=diagnosticHTML();
 if(p==='parcels')html=head('Gestion des colis',isAll()?'Tous les colis du réseau, en lecture seule.':'Les colis qui partent de '+esc(ME())+' ou qui arrivent chez vous.',can('parcel.write')?`<button class="primary" id="addParcel">+ Enregistrer un colis</button>`:'')+`<div class="toolbar"><input id="searchP" placeholder="Rechercher une référence ou un nom"><select id="filterP"><option value="">Tous les statuts</option>${['Enregistré','Emballé','En transit','Arrivé','Livré'].map(s=>`<option>${s}</option>`)}</select><select id="scopeP">${scopeOpts('p').map(s=>`<option>${esc(s)}</option>`).join('')}</select></div><div id="parcelTable">${table(vP(),'p')}</div>${groupSection()}`;
 if(p==='transfers')html=prepaidCard()+head('Registre des transferts',isAll()?'Tous les transferts du réseau, en lecture seule.':'Transferts émis par '+esc(ME())+' et transferts à payer dans votre agence.',can('transfer.write')?`<button class="primary" id="addTransfer">+ Enregistrer</button>`:'')+`<div class="notice">${can('transfer.pay')?'Confirmez le paiement uniquement après vérification de la réception réelle par le bénéficiaire. La confirmation met à jour le registre et le solde de votre agence ; elle ne transfère pas d’argent.':'Vue de contrôle : seuls le caissier et le directeur de l’agence qui paie confirment un paiement.'}</div><div class="toolbar"><input id="searchT" placeholder="Rechercher un nom ou une référence"><select id="scopeT">${scopeOpts('t').map(s=>`<option>${esc(s)}</option>`).join('')}</select></div><div id="transferTable">${table(vT(),'t')}</div>`;
 if(p==='finances')html=financesHTML();
 if(p==='agencies')html=agenciesHTML();
 if(p==='customers')html=head('Espace clients','Accès personnel obligatoire.')+`<section class="panel"><h3>Règles d'accès client</h3><div class="notice">Chaque client devra se connecter à son compte. Il ne pourra consulter que les colis et transferts associés à son profil. Le suivi public par simple numéro ne sera pas activé.</div><p>Inscription, vérification d'e-mail et récupération du mot de passe seront connectées à Firebase Authentication.</p></section>`;
 if(p==='reports')html=head('Rapports','Indicateurs réels à connecter à la base de données.')+`<div class="stats"><div class="card"><span>Colis entrants</span><strong>—</strong><small>RDC vers Bénin</small></div><div class="card"><span>Colis sortants</span><strong>—</strong><small>Bénin vers RDC</small></div><div class="card"><span>Transferts</span><strong>—</strong><small>Toutes devises</small></div><div class="card"><span>Écarts de caisse</span><strong>—</strong><small>Après rapprochement</small></div></div>`;
 if(p==='settings')html=head('Paramètres','Configuration générale.')+`<section class="panel"><h3>Configuration du réseau</h3><div class="formgrid"><label>Nom de la plateforme<input value="TransitLink (provisoire)" disabled></label><label>Devises<select disabled><option>FCFA · USD · CDF</option></select></label><label>Connexion<select disabled><option>En ligne uniquement</option></select></label><label>Accès client<select disabled><option>Compte obligatoire</option></select></label></div><div class="notice">Le nom et le logo officiels seront intégrés dès réception.</div></section>`;
 $('#content').innerHTML=html;setHH();wire(p);setupMini(p);centerPills()}
function setHH(){const h=document.querySelector('main header');if(!h||!h.offsetHeight)return;const st=getComputedStyle(h).position==='sticky';document.documentElement.style.setProperty('--hh',(st?h.offsetHeight+16:10)+'px');syncMini()}
addEventListener('resize',setHH);addEventListener('orientationchange',()=>setTimeout(setHH,250));addEventListener('load',setHH);if(document.fonts&&document.fonts.ready)document.fonts.ready.then(setHH);if(window.ResizeObserver){const _h=document.querySelector('main header');if(_h)new ResizeObserver(setHH).observe(_h)}
function others(){return AGN.filter(x=>x!==ME())}
function wire(p){
 if(p==='parcels'){const render=()=>{const q=$('#searchP').value.toLowerCase(),f=$('#filterP').value,sc=$('#scopeP').value;$('#parcelTable').innerHTML=table(vP().filter(x=>(!f||x.status===f)&&inScope(x,'p',sc)&&Object.values(x).join(' ').toLowerCase().includes(q)),'p')};$('#searchP').oninput=render;$('#filterP').onchange=render;$('#scopeP').onchange=render;
  const add=$('#addParcel');if(add)add.onclick=()=>{const dest=others();if(!can('parcel.write'))return;if(!dest.length){tlAlert('Destination manquante','Ajoutez au moins une autre ville dans « Mon agence » pour enregistrer un colis.');return}
   openForm('Enregistrer un colis',[{k:'s',l:'Expéditeur',req:1,ph:'Nom complet'},{k:'r',l:'Destinataire',req:1,ph:'Nom complet'},{k:'from',l:'Agence de départ (la vôtre)',o:[ME()],d:ME()},{k:'to',l:'Agence d’arrivée',o:dest,d:dest.includes('Cotonou')?'Cotonou':dest[0]},{k:'desc',l:'Description du colis',req:1,ph:'Ex. Vêtements, 2 cartons'},{k:'w',l:'Poids en kg (facultatif)',t:'number',ph:'Ex. 12'},{k:'fee',l:'Frais d’expédition',t:'number',req:1,min:1,ph:'Ex. 36000'},{k:'cur',l:'Devise',o:CURS}],v=>{const r=mkP('TL-'+Date.now().toString().slice(-5),v.s,v.r,ME(),v.to,new Date().toLocaleDateString('fr-FR'),'Enregistré',v.desc,v.w,Number(v.fee),v.cur);r.by=sess.name;parcels.unshift(r);logEv('Colis '+r.id+' enregistré');render();tlToast('Colis enregistré');TLInvoice.open('p',r)},v=>v.w&&Number(v.w)<0?'Le poids doit être positif.':'')}}
 if(p==='transfers'){const render=()=>{const q=$('#searchT').value.toLowerCase(),sc=$('#scopeT').value;$('#transferTable').innerHTML=table(vT().filter(x=>inScope(x,'t',sc)&&Object.values(x).join(' ').toLowerCase().includes(q)),'t')};$('#searchT').oninput=render;$('#scopeT').onchange=render;
  const add=$('#addTransfer');if(add)add.onclick=()=>{const dest=others();if(!can('transfer.write'))return;if(!dest.length){tlAlert('Destination manquante','Ajoutez au moins une autre ville dans « Mon agence » pour enregistrer un transfert.');return}
   openForm('Enregistrer un transfert',[{k:'s',l:'Expéditeur',req:1},{k:'b',l:'Bénéficiaire',req:1},{k:'amount',l:'Montant à transférer',t:'number',req:1,min:1,ph:'Ex. 150000'},{k:'fee',l:'Frais de service (facultatif)',t:'number',ph:'Ex. 3000'},{k:'cur',l:'Devise',o:CURS},{k:'from',l:'Agence d’envoi (la vôtre)',o:[ME()],d:ME()},{k:'ag',l:'Agence qui paie le bénéficiaire',o:dest,d:dest.includes('Cotonou')?'Cotonou':dest[0]}],v=>{const r=mkT('TR-'+Date.now().toString().slice(-5),v.s,v.b,Number(v.amount),v.cur,ME(),v.ag,'En attente',new Date().toLocaleDateString('fr-FR'));r.fee=Number(v.fee||0);r.creePar=sess.name;transfers.unshift(r);logEv('Transfert '+r.id+' enregistré');render();tlToast('Transfert enregistré');TLInvoice.open('t',r)},v=>Number(v.fee||0)<0?'Les frais ne peuvent pas être négatifs.':'')}}}

/* ───────── Clics dans la page ───────── */
$('#content').addEventListener('click',ev=>{
 const ab=ev.target.closest('[data-addbudget]');if(ab){const[a,c]=ab.dataset.addbudget.split('|');openAddBudget(a,c);return}
 const pa=ev.target.closest('[data-cardag]'),pcu=ev.target.closest('[data-cardcur]');
 if(pa&&isAll()){cardAg=pa.dataset.cardag;refreshCard();return}if(pcu){cardCur=pcu.dataset.cardcur;refreshCard();return}
 if(ev.target.closest('[data-cardadd]')){openAddBudget(cardAg,cardCur);return}
 if(ev.target.closest('[data-cardtop]')){window.scrollTo({top:0,behavior:'smooth'});return}
 const db=ev.target.closest('[data-delbudget]');if(db){const i=budgetLedger.findIndex(x=>x.id===db.dataset.delbudget);if(i<0)return;const e=budgetLedger[i];if(!can('budget.write')||e.agency!==ME())return;if(budgetLeft(e.agency,e.cur,e.day)-e.amount<0){tlAlert('Annulation impossible','Une partie de cet argent a déjà été utilisée pour des paiements.');return}
  tlDialog({title:'Annuler cet ajout ?',body:`<p>L’ajout de <b>${money(e.amount)} ${esc(e.cur)}</b> pour l’agence <b>${esc(e.agency)}</b> sera retiré du budget du jour.</p>`,actions:[{label:'Garder'},{label:'Annuler l’ajout',primary:1,danger:1,onClick:()=>{const k=budgetLedger.findIndex(x=>x.id===e.id);if(k<0)return;budgetLedger.splice(k,1);try{saveBudgets()}catch(x){}tlToast('Ajout annulé');page('finances')}}]});return}
 const paid=ev.target.closest('[data-paid]');if(paid){payTransfer(paid.dataset.paid);return}
 const stp=ev.target.closest('[data-step]');if(stp){const p=parcels.find(x=>x.id===stp.dataset.step),s=p&&parcelStep(p);if(!s)return;p.status=s[1];logEv('Colis '+p.id+' → '+s[1]);tlToast('Colis '+p.id+' : '+s[1]);page('parcels');return}
 const ng=ev.target.closest('[data-newgroup]');if(ng){newGroup();return}
 const ga=ev.target.closest('[data-gadd]');if(ga){addToGroup(ga.dataset.gadd);return}
 const gs=ev.target.closest('[data-gship]');if(gs){shipGroup(gs.dataset.gship);return}
 const gr=ev.target.closest('[data-garr]');if(gr){arriveGroup(gr.dataset.garr);return}
 const b=ev.target.closest('[data-inv]');if(!b)return;const[k,id]=b.dataset.inv.split(':'),r=(k==='p'?vP():vT()).find(x=>x.id===id);if(r)TLInvoice.open(k,r)});

/* ───────── Connexion et navigation ───────── */
function fillLogin(){const rs=$('#roleSel'),ag=$('#agSel');ag.innerHTML=AGN.map(a=>`<option>${esc(a)}</option>`).join('');const upd=()=>{$('#agWrap').classList.toggle('hidden',TLAccess.all(rs.value));$('#roleHint').textContent=TLAccess.ROLES[rs.value].hint};rs.onchange=upd;upd();if(AGN.includes('Cotonou'))ag.value='Cotonou'}
function enter(s){sess=s;try{sessionStorage.setItem(SESS_KEY,JSON.stringify(s))}catch(e){}cardAg=s.agency||'';cardCur='FCFA';
 const pages=TLAccess.pages(s.role);document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('hidden',!pages.includes(b.dataset.page)));
 $('#who').innerHTML=`<b>${esc(TLAccess.label(s.role))}</b><span>${TLAccess.all(s.role)?'Tout le réseau':'Agence de '+esc(s.agency)}</span>`;
 $('#eb').textContent=TLAccess.all(s.role)?'PROPRIÉTAIRE · TOUT LE RÉSEAU':'AGENCE DE '+s.agency.toUpperCase()+' · '+TLAccess.label(s.role).toUpperCase();
 $('#login').classList.add('hidden');$('#app').classList.remove('hidden');page(TLAccess.home(s.role));window.scrollTo(0,0)}
function leave(){sess=null;try{sessionStorage.removeItem(SESS_KEY)}catch(e){}const m=document.getElementById('pmini');if(m)m.remove();$('#app').classList.add('hidden');$('#login').classList.remove('hidden')}
$('#date').textContent=new Date().toLocaleDateString('fr-FR',{dateStyle:'medium'});
fillLogin();
$('#demo').onclick=()=>{const role=$('#roleSel').value,all=TLAccess.all(role),ag=all?'':$('#agSel').value;if(!all&&!ag){tlAlert('Agence manquante','Choisissez votre agence.');return}enter({role,agency:ag,name:DEMO_NAMES[role]+(all?'':' '+ag)})};
$('#logout').onclick=$('#logout2').onclick=leave;
document.querySelector('nav').onclick=e=>{const b=e.target.closest('[data-page]');if(!b)return;b.scrollIntoView({inline:'center',block:'nearest',behavior:'smooth'});page(b.dataset.page);window.scrollTo(0,0)};
try{const s=JSON.parse(sessionStorage.getItem(SESS_KEY)||'null');if(s&&TLAccess.ok(s.role)&&(TLAccess.all(s.role)||AGN.includes(s.agency)))enter(s)}catch(e){}
