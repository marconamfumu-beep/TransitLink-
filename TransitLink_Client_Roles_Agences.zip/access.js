/* Rôles et permissions (démonstration).
   ATTENTION : en démonstration le filtrage se fait dans le navigateur. En production, la vraie protection
   est dans firestore.rules (rôle + agence lus dans le jeton de connexion, impossibles à modifier côté client). */
const TLAccess=(function(){
const R={
 proprietaire:{label:'Propriétaire',hint:'Voit tout le réseau en lecture seule : colis, transferts, budgets et cartes de toutes les agences, avec le diagnostic complet. Ne modifie rien.',all:1,
  pages:['diagnostic','parcels','transfers','finances','agencies','customers','reports','settings'],can:[]},
 directeur:{label:'Directeur d’agence',hint:'Voit uniquement son agence : ses colis, ses transferts, son budget et sa carte, ainsi que ce que les autres agences ont envoyé vers lui.',
  pages:['overview','parcels','transfers','finances'],can:['parcel.write','parcel.step','group.write','transfer.write','transfer.pay','budget.write']},
 caissier_colis:{label:'Caissier(ère) / Agent colis',hint:'Voit uniquement son agence : il note et emballe les colis, enregistre les transferts, gère son budget du jour et sa carte prépayée, y compris ce que les autres agences ont envoyé vers lui.',
  pages:['overview','parcels','transfers','finances'],can:['parcel.write','parcel.step','group.write','transfer.write','transfer.pay','budget.write']}
};
return{ROLES:R,
 ok:r=>!!R[r],
 all:r=>!!(R[r]&&R[r].all),
 can:(r,p)=>!!(R[r]&&R[r].can.includes(p)),
 pages:r=>R[r]?R[r].pages:[],
 home:r=>R[r]?R[r].pages[0]:'',
 label:r=>R[r]?R[r].label:''};
})();
