const tlEsc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function tlToast(t){let e=document.getElementById('tltoast');if(!e){e=document.createElement('div');e.id='tltoast';e.className='tltoast';document.body.appendChild(e)}e.textContent=t;e.classList.add('on');clearTimeout(e._t);e._t=setTimeout(()=>e.classList.remove('on'),2600)}
function openForm(title,fields,onSubmit,chk){const o=document.createElement('div');o.className='mo';o.innerHTML=`<form class="mbox" novalidate><h3>${title}</h3>${fields.map(f=>`<label>${f.l}${f.o?`<select name="${f.k}">${f.o.map(x=>`<option${x===f.d?' selected':''}>${tlEsc(x)}</option>`).join('')}</select>`:`<input name="${f.k}" type="${f.t||'text'}" ${f.min?`min="${f.min}"`:''} placeholder="${f.ph||''}" ${f.v!==undefined?`value="${tlEsc(f.v)}"`:''} autocomplete="off">`}</label>`).join('')}<p class="merr" role="alert"></p><div class="mact"><button type="button" class="btn-s" data-x>Annuler</button><button class="primary">Enregistrer</button></div></form>`;
const k=e=>{if(e.key==='Escape')close()},close=()=>{o.remove();document.removeEventListener('keydown',k)};document.addEventListener('keydown',k);
o.onclick=e=>{if(e.target===o||e.target.dataset.x!==undefined)close()};
o.querySelector('form').onsubmit=e=>{e.preventDefault();const v={};fields.forEach(f=>v[f.k]=(o.querySelector(`[name=${f.k}]`).value||'').trim());const bad=fields.find(f=>f.req&&(!v[f.k]||(f.t==='number'&&!(+v[f.k]>0))||(f.t==='email'&&!/^\S+@\S+\.\S+$/.test(v[f.k]))));const m=bad?`Veuillez renseigner correctement « ${bad.l} ».`:(chk&&chk(v))||'';if(m){o.querySelector('.merr').textContent=m;return}onSubmit(v);close()};
document.body.appendChild(o);const i=o.querySelector('input,select');if(i)i.focus()}

function tlConfirm(title,msg,onOk){const o=document.createElement('div');o.className='mo';o.innerHTML=`<div class="mbox" role="dialog" aria-modal="true"><h3>${tlEsc(title)}</h3><p style="margin:0 0 20px;color:#4a6370;line-height:1.6;font-size:14px">${tlEsc(msg)}</p><div class="mact"><button type="button" class="btn-s" data-x>Annuler</button><button type="button" class="primary" data-ok style="background:#c24e55">Supprimer</button></div></div>`;
const k=e=>{if(e.key==='Escape')close()},close=()=>{o.remove();document.removeEventListener('keydown',k)};document.addEventListener('keydown',k);
o.onclick=e=>{if(e.target===o||e.target.dataset.x!==undefined)close();else if(e.target.dataset.ok!==undefined){close();onOk()}};document.body.appendChild(o);o.querySelector('[data-ok]').focus()}

function tlDialog(o){const d=document.createElement('div');d.className='mo';const acts=o.actions||[{label:'Fermer'}];
d.innerHTML=`<div class="mbox tld" role="dialog" aria-modal="true"><h3>${tlEsc(o.title)}</h3><div class="tld-body">${o.body||''}</div><div class="mact">${acts.map((a,i)=>`<button type="button" class="${a.primary?'primary':'btn-s'}" data-i="${i}"${a.danger?' style="background:#c24e55"':''}>${tlEsc(a.label)}</button>`).join('')}</div></div>`;
const k=e=>{if(e.key==='Escape')close()},close=()=>{d.remove();document.removeEventListener('keydown',k)};document.addEventListener('keydown',k);
d.onclick=e=>{if(e.target===d){close();return}const b=e.target.closest('[data-i]');if(!b)return;const a=acts[+b.dataset.i];close();if(a&&a.onClick)a.onClick()};
document.body.appendChild(d);const p=d.querySelector('.primary')||d.querySelector('[data-i]');if(p)p.focus()}
function tlAlert(title,msg){tlDialog({title,body:`<p>${tlEsc(msg)}</p>`})}
