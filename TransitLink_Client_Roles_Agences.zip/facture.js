/* Facture imprimable : colis et transferts. Formats A4 et ticket 80 mm. */
const TLInvoice=(function(){
const e=s=>TL.esc(s==null?'':s),n=v=>Number(v||0).toLocaleString('fr-FR');
let fmt='a4',cur=null,box=null;try{if(localStorage.getItem('tl_fmt')==='t80')fmt='t80'}catch(e){}
function build(k,x){const a=TL.get(),name=a.name||'TransitLink',logo=a.logo||'logo-emblem.png',m=x.cur||'FCFA';
 let title,sub,l1,l2,l3,v3,lines,total,terms,who;
 if(k==='p'){const fee=Number(x.fee||0);title='Facture d’expédition';sub='Envoi de colis';l1='Expéditeur';l2='Destinataire';l3='Trajet';v3=e(x.from)+' → '+e(x.to);who=[x.sender,x.receiver];
  lines=[['Frais d’expédition',e(x.desc||'Colis')+(x.weight?' · '+n(x.weight)+' kg':''),fee]];total=fee;
  terms='Conservez ce document : il est nécessaire pour suivre le colis, le retirer et pour toute réclamation. Les conditions générales de l’agence s’appliquent.'}
 else{const v=Number(x.val||0),fee=Number(x.fee||0);title='Facture de transfert';sub='Transfert d’argent';l1='Expéditeur';l2='Bénéficiaire';l3='Agence d’envoi → paiement';v3=e(x.from||x.agency)+' → '+e(x.agency);who=[x.sender,x.beneficiary];
  lines=[['Montant transféré','Montant destiné au bénéficiaire',v],['Frais de service','Commission de l’agence',fee]];total=v+fee;
  terms='Le bénéficiaire doit présenter une pièce d’identité et ce document pour tout retrait. Conservez-le : il est nécessaire pour toute réclamation. Les conditions générales de l’agence s’appliquent.'}
 const now=new Date().toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'});
 return `<article class="sheet${fmt==='t80'?' t80':''}"><header class="ih"><div class="ibrand"><img class="ilogo" src="${a.logo?e(a.logo):'logo-emblem.png'}" alt=""><div><b>${e(name)}</b><span>${a.cities.slice(0,5).map(e).join(' · ')}</span></div></div>
<div class="imeta"><h1>FACTURE</h1><em>${title}</em><dl><dt>N°</dt><dd>${e(x.id)}</dd><dt>Date</dt><dd>${e(x.date||'')}</dd><dt>Statut</dt><dd>${e(x.status||'')}</dd></dl></div></header>
<section class="iparties"><div><h4>${l1}</h4><p><b>${e(who[0])}</b></p></div><div><h4>${l2}</h4><p><b>${e(who[1])}</b></p></div><div><h4>${l3}</h4><p><b>${v3}</b></p></div></section>
<table class="itab"><thead><tr><th>Désignation</th><th>Détail</th><th class="r">Montant (${e(m)})</th></tr></thead><tbody>${lines.map(l=>`<tr><td><b>${l[0]}</b><small class="dt">${l[1]}</small></td><td class="dc">${l[1]}</td><td class="r">${n(l[2])}</td></tr>`).join('')}</tbody></table>
<div class="itot"><div class="box"><div class="grand"><span>TOTAL À PAYER</span><b>${n(total)} ${e(m)}</b></div></div></div>
<section class="ifoot"><div class="sign"><span>Cachet et signature de l’agence</span></div><div class="sign"><span>Signature du client</span></div></section>
<p class="iterms">${terms}</p><p class="ithanks">Merci de votre confiance · ${e(name)}</p><p class="iissued">Document émis le ${now}</p></article>`}
function setPage(){let s=document.getElementById('tl-page');if(!s){s=document.createElement('style');s.id='tl-page';document.head.appendChild(s)}s.textContent=fmt==='a4'?'@page{size:A4;margin:12mm}':'@page{size:80mm auto;margin:3mm}'}
function paint(){if(!box)return;box.querySelector('.paper').innerHTML=build(cur[0],cur[1]);box.querySelectorAll('.seg button').forEach(b=>b.classList.toggle('on',b.dataset.f===fmt));setPage()}
function close(){if(box){box.remove();box=null;document.body.style.overflow='';document.removeEventListener('keydown',kd)}}
function kd(ev){if(ev.key==='Escape')close()}
function open(k,x){close();cur=[k,x];box=document.createElement('div');box.id='tl-inv';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');
 box.innerHTML='<div class="tb"><b>Aperçu de la facture</b><div class="seg" role="group" aria-label="Format d’impression"><button type="button" data-f="a4">A4</button><button type="button" data-f="t80">Ticket 80 mm</button></div><div class="tbr"><button type="button" class="btn-s" data-c>Fermer</button><button type="button" class="primary" data-p>Imprimer</button></div></div><div class="paper"></div>';
 box.onclick=ev=>{const t=ev.target;if(t.dataset.f){fmt=t.dataset.f;try{localStorage.setItem('tl_fmt',fmt)}catch(e){}paint()}else if(t.dataset.c!==undefined)close();else if(t.dataset.p!==undefined){setPage();window.print()}};
 document.body.appendChild(box);document.body.style.overflow='hidden';document.addEventListener('keydown',kd);paint()}
return{open,close};
})();
