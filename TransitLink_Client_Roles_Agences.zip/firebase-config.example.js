// Copiez ce fichier en « firebase-config.js » et collez les valeurs de Firebase
// (Console Firebase > Paramètres du projet > Vos applications > Application Web).
window.FIREBASE_CONFIG={apiKey:"",authDomain:"",projectId:"",storageBucket:"",messagingSenderId:"",appId:""};
