# TransitLink : version agence (client) — guide de mise en ligne

Cette version est celle de l'agence : une seule organisation, ses agences (Kinshasa, Lubumbashi, Goma, Cotonou) et ses utilisateurs. Elle est autonome : aucun fichier de la plateforme multi-agences.

Pages : `index.html` (application du personnel) · `admin.html` (administration, application installable) · `logo*.svg`.

## 1. Firebase
1. console.firebase.google.com > Ajouter un projet (au nom de l'agence ; le projet appartient idéalement à l'agence).
2. Authentication > activer « E-mail/Mot de passe ».
3. Firestore Database > Créer une base (mode production).
4. Paramètres du projet > Vos applications > Web : copiez la configuration dans `firebase-config.js` (modèle : `firebase-config.example.js`).
5. `npm i -g firebase-tools` puis `firebase login`, `firebase use --add`, `firebase deploy --only firestore:rules`.
6. Créez les comptes dans Authentication, puis donnez les rôles : `node scripts/set-claims.js proprio@agence.com proprietaire` ou, pour le personnel d'une agence, `node scripts/set-claims.js caisse@agence.com caissier_colis Cotonou` (nécessite `npm install` et un compte de service : `GOOGLE_APPLICATION_CREDENTIALS=serviceAccount.json`).

## 2. Netlify
Glissez le dossier sur app.netlify.com/drop, ou importez le dépôt Git (aucune commande de build, dossier publié : `.`). Ajoutez le domaine de l'agence (HTTPS automatique).

## 3. Changer le nom ou le logo
Remplacez « TransitLink » dans `index.html`, `admin.html`, `app.js`, `manifest.webmanifest`, puis `logo.svg`, `icon-192.png`, `icon-512.png`.

## 4. Installer l'application
Android/Chrome : bouton « Installer ». iPhone : Safari > Partager > Sur l'écran d'accueil.

## 5. Encore à brancher
Connexion réelle (Firebase Auth), lecture/écriture Firestore à la place des tableaux en mémoire, reçus PDF, notifications. Tout flux d'argent réel demande un partenaire agréé.


## Logo, nom et villes de l'agence
L'administrateur les modifie dans `admin.html` > **Mon agence** (logo, nom, ajout et suppression de villes).
En démonstration, ces réglages sont gardés dans le navigateur. Au branchement : le nom et les villes iront dans Firestore, le logo dans Firebase Storage (`firebase deploy --only storage`, règles dans `storage.rules`, logos de 2 Mo maximum réservés à la direction et aux administrateurs).

## Factures
Chaque colis et chaque transfert enregistré ouvre automatiquement l'aperçu de la facture (bouton « Facture » sur chaque ligne pour la rééditer). Formats : A4 et ticket 80 mm (imprimantes de caisse). Le logo et le nom de l'agence (page « Mon agence ») figurent sur la facture. Les numéros de facture suivent pour l'instant la référence du colis ou du transfert ; au branchement Firestore, prévoir une numérotation séquentielle côté serveur.


## Solde automatique par agence
Dans Transferts, le bouton « Confirmer payé » permet au responsable de confirmer un paiement réellement effectué. Le montant est alors déduit du solde de l'agence et apparaît dans Finances, par agence et par devise (FCFA, USD, CDF). Une référence déjà comptabilisée ne peut pas être déduite une seconde fois dans l'interface. Cette version de démonstration stocke le registre dans le navigateur (localStorage), donc les données ne sont pas partagées entre appareils. Pour la production, utiliser une transaction Firestore/Cloud Function sécurisée, des rôles vérifiés côté serveur et un journal d'audit.


## Budget du jour par agence
Dans Finances (et en résumé dans Transferts), chaque agence enregistre l'argent qu'elle a en main avant de commencer les travaux : bouton « + Ajouter » par devise (FCFA, USD, CDF) ou « + Ajouter de l'argent » en haut. Il est possible d'ajouter plusieurs fois dans la journée. Chaque fiche affiche Budget, Utilisé et Reste, et le « Reste » baisse à chaque « Confirmer payé ». Un paiement est refusé si aucun budget n'est enregistré aujourd'hui ou si le reste est insuffisant. Un ajout peut être annulé tant que l'argent n'a pas été utilisé. Le budget est calculé par jour : le lendemain, il repart de zéro. Il s'agit d'un simple enregistrement, aucun argent réel n'est déplacé. Démonstration : données dans le navigateur (localStorage, clé `tl_agency_budgets_v1`) ; au branchement, collection Firestore `budgets` (règles déjà prévues dans `firestore.rules`).


## Rôles et visibilité (chaque agence ne voit que ce qui la concerne)
| Profil | Colis | Transferts d'argent | Budget et carte prépayée |
|---|---|---|---|
| **Propriétaire** (grand chef) | Tous, lecture seule | Tous, lecture seule | Toutes les caisses et cartes, lecture seule (n'ajoute pas d'argent) + page **Diagnostic** |
| **Directeur d'agence** | Ceux de son agence | Ceux de son agence | Son agence, il peut ajouter au budget et confirmer les paiements |
| **Caissier(ère) / Agent colis** (une seule personne) | Ceux de son agence : enregistre, emballe, expédie | Ceux de son agence | Son agence : ajoute au budget et confirme les paiements |

« Ceux de son agence » = ce que l'agence a **envoyé** et ce que les **autres agences ont fait pour elle** (colis qui arrivent chez elle, transferts qu'elle doit payer). Exemple : Cotonou voit ses propres colis et transferts, plus tout ce que Kinshasa, Lubumbashi ou Goma ont envoyé vers Cotonou, et rien d'autre.

Champs utilisés dans Firestore : colis `from` / `to` ; transferts `from` (agence d'envoi) et `agency` (agence qui paie) ; budgets et mouvements `agency`. Les rôles et l'agence viennent du jeton de connexion (`role`, `agence`), posés par `scripts/set-claims.js` ; `firestore.rules` applique ces règles côté serveur.

**Important** : dans cette version de démonstration, le filtrage est fait dans le navigateur pour montrer le résultat. La vraie sécurité sera celle de `firestore.rules`, une fois Firebase branché. Redéployez-les : `firebase deploy --only firestore:rules`.

## Groupages de colis (100 kg maximum)
Dans la page Colis, section « Groupages » : le **directeur** et le **caissier(ère) / agent colis** peuvent créer un groupage vers une agence, y ajouter des colis (du même départ et de la même destination, poids renseigné) et l'expédier. Un groupage ne dépasse jamais **100 kg**. Ils peuvent ouvrir **plusieurs groupages** et expédier un groupage **même s'il n'est pas plein**. Les colis doivent être emballés avant l'expédition ; à l'expédition ils passent « En transit », et l'agence d'arrivée marque le groupage « Arrivé ». Le propriétaire voit tous les groupages en lecture seule (page Colis et Diagnostic). Firestore : collection `groupages` (`from`, `to`, `poidsTotal`, `status`) ; les colis portent le champ `group`.

## Diagnostic du propriétaire
Page « Diagnostic » : alertes (budget absent ou insuffisant par rapport aux transferts à payer, colis non emballés, colis à remettre), état de chaque agence, flux entre agences (colis et transferts), volumes par devise et derniers mouvements de caisse.
